Videoner extension for QupZilla
-------------------------------------------------
This extension allows you to open links in video sharing platforms in an external program. 

![yt1](http://i.imgur.com/vgtKUCJ.png)

You will find more information about the configuration and usage of this extension in the [wiki](https://github.com/QupZilla/qupzilla-plugins/wiki/Videoner).