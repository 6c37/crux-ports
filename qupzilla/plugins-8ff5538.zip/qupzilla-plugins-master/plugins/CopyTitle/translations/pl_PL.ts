<?xml version="1.0" ?><!DOCTYPE TS><TS language="pl_PL" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Kopiuj tytuł strony</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Kopiuj nazwę obrazka</translation>
    </message>
</context>
</TS>