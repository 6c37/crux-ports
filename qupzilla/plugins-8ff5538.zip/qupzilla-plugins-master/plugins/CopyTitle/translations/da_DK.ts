<?xml version="1.0" ?><!DOCTYPE TS><TS language="da_DK" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Kopiér side titel</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Kopier billednavn</translation>
    </message>
</context>
</TS>