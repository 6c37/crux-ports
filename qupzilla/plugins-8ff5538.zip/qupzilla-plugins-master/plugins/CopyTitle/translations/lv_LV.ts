<?xml version="1.0" ?><!DOCTYPE TS><TS language="lv_LV" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Kopēt lapas nosaukumu</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Kopēt attēla nosaukumu</translation>
    </message>
</context>
</TS>