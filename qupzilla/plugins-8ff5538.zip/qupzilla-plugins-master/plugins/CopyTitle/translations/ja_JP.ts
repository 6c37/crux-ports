<?xml version="1.0" ?><!DOCTYPE TS><TS language="ja_JP" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>ページ名のコピー</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>画像の名前をコピー</translation>
    </message>
</context>
</TS>