<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Copiar título da página</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Copiar nome da imagem</translation>
    </message>
</context>
</TS>