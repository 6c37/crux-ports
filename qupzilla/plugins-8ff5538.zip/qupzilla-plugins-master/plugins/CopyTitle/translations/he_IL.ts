<?xml version="1.0" ?><!DOCTYPE TS><TS language="he_IL" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>העתק כותרת עמוד</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>העתק שם תמונה</translation>
    </message>
</context>
</TS>