<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr@ijekavianlatin" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Kopiraj naslov stranice</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Kopiraj ime slike</translation>
    </message>
</context>
</TS>