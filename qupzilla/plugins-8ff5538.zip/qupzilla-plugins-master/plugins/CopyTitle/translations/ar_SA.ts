<?xml version="1.0" ?><!DOCTYPE TS><TS language="ar_SA" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>انسخ عنوان الصفحة</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>انسخ اسم الصورة</translation>
    </message>
</context>
</TS>