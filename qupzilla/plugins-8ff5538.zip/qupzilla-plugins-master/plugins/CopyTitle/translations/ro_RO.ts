<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro_RO" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Copiere titlu pagină</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Copiere nume imagine</translation>
    </message>
</context>
</TS>