<?xml version="1.0" ?><!DOCTYPE TS><TS language="is" version="2.0">
<context>
    <name>CopyTitle</name>
    <message>
        <source>Copy Page Title</source>
        <translation>Afrita titil síðu</translation>
    </message>
    <message>
        <source>Copy Image Name</source>
        <translation>Afrita heiti myndar</translation>
    </message>
</context>
</TS>