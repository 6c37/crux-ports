Readability plugin for QupZilla
-------------------------------------------------
This plugin allows modify web page to easily reading.

![example](http://i.imgur.com/SnQNfQl.png)

You will find more information about usage of this plugin in the [wiki](https://github.com/QupZilla/qupzilla-plugins/wiki/Readability).
