<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk_UA" version="2.0">
<context>
    <name>MailHandle_Settings</name>
    <message>
        <source>MailHandle Settings</source>
        <translation>Налаштування підтримувача пошти</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:x-large; font-weight:600;&quot;&gt;Mailto links handler&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:x-large; font-weight:600;&quot;&gt;Обробник посилань mailto&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Web service to use:</source>
        <translation>Вживаний веб-сервіс:</translation>
    </message>
    <message>
        <source>Gmail</source>
        <translation>Gmail</translation>
    </message>
    <message>
        <source>Mail.ru</source>
        <translation>Mail.ru</translation>
    </message>
    <message utf8="true">
        <source>Яandex</source>
        <translation>Яandex</translation>
    </message>
    <message>
        <source>Outlook</source>
        <translation>Outlook</translation>
    </message>
    <message>
        <source>Yahoo!</source>
        <translation>Yahoo!</translation>
    </message>
    <message>
        <source>My Opera</source>
        <translation>My Opera</translation>
    </message>
    <message>
        <source>FastMail</source>
        <translation>FastMail</translation>
    </message>
    <message>
        <source>T-Online</source>
        <translation>T-Online</translation>
    </message>
    <message>
        <source>RoundCube</source>
        <translation>RoundCube</translation>
    </message>
    <message>
        <source>Enter URL of your webmail service provider. For example:
https://somewebsite/roundcube</source>
        <translation>Введіть URL-адресу вашого постачальника веб-пошти. Наприклад:
https://somewebsite/roundcube</translation>
    </message>
    <message>
        <source>URL of the webmail service provider:</source>
        <translation>URL-адреса постачальника веб-пошти:</translation>
    </message>
</context>
</TS>