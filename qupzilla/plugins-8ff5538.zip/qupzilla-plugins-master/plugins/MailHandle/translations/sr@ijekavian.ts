<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr@Ijekavian" version="2.0">
<context>
    <name>MailHandle_Settings</name>
    <message>
        <source>MailHandle Settings</source>
        <translation>Поставке Руковаоца поште</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:x-large; font-weight:600;&quot;&gt;Mailto links handler&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:x-large; font-weight:600;&quot;&gt;Руковалац везама е-поште&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Web service to use:</source>
        <translation>Веб сервис е-поште:</translation>
    </message>
    <message>
        <source>Gmail</source>
        <translation>ГМејл</translation>
    </message>
    <message>
        <source>Mail.ru</source>
        <translation>Мејл.ру</translation>
    </message>
    <message utf8="true">
        <source>Яandex</source>
        <translation>Јандекс</translation>
    </message>
    <message>
        <source>Outlook</source>
        <translation>Аутлук</translation>
    </message>
    <message>
        <source>Yahoo!</source>
        <translation>Јаху!</translation>
    </message>
    <message>
        <source>My Opera</source>
        <translation>Моја Опера</translation>
    </message>
    <message>
        <source>FastMail</source>
        <translation>Фастмејл</translation>
    </message>
    <message>
        <source>T-Online</source>
        <translation>Т-онлајн</translation>
    </message>
    <message>
        <source>RoundCube</source>
        <translation>РаундКјуб</translation>
    </message>
    <message>
        <source>Enter URL of your webmail service provider. For example:
https://somewebsite/roundcube</source>
        <translation>Унесите УРЛ даваоца услуге веб поште. На примјер:
https://nekivebsajt/roundcube</translation>
    </message>
    <message>
        <source>URL of the webmail service provider:</source>
        <translation>УРЛ даваоца услуге веб поште:</translation>
    </message>
</context>
</TS>