Fergris theme for QupZilla
========================

Full theme for QupZilla with own Qt style, created by [cranes-bill](https://github.com/cranes-bill).

*Please note: To make this theme work as intended, you will have to download the true-type font DexterC.ttf. Since the licensing of this font is not clear, we will not provide it with this theme. Please download the font DexterC.ttf [here](http://www.azfonts.net/load_font/dexterc.html) save it to the fonts directory.*

Screenshots:<br>


![fergris1](https://cloud.githubusercontent.com/assets/5161278/5666119/febb6fde-9765-11e4-8aee-958658c77886.png)

![fergris2](https://cloud.githubusercontent.com/assets/5161278/5666123/04f08c7c-9766-11e4-8b29-7cd2301a1aef.png)

![fergris3](https://cloud.githubusercontent.com/assets/5161278/5666126/085ae876-9766-11e4-8f76-982387f3cb5c.png)

![fergris4](https://cloud.githubusercontent.com/assets/5161278/5666133/0c601f18-9766-11e4-9ef6-27037cb441bc.png)
