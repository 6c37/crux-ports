Cyanotype theme for QupZilla
========================

Simple, modern blue-white theme for QupZilla, created by [cranes-bill](https://github.com/cranes-bill).

Screenshot:<br>


![cyano1](https://cloud.githubusercontent.com/assets/5161278/5893387/4d3c3f94-a4ea-11e4-9e0b-272b80ef368f.png)
