Classic Winstripe theme for QupZilla
========================

The original Winstripe theme from 0.9, a blast from the past, created by [GreenLunar](https://github.com/GreenLunar)

Screenshot:
![winstripe](http://i.imgur.com/wq9GPDY.png)